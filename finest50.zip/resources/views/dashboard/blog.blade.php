@extends('layout.dashboard')

@section('title', 'Dashboard - Blogs')

@section('content')
    <!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid pt-10" id="kt_content">

        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Dashboard-->

                <div class="row">
                    <div class="col-12">
                        <div class="card card-custom gutter-b">
                            <div class="card-header">
                                <h3 class="card-title">Upload Blog</h3>
                                <div class="card-toolbar">
                                    <div class="example-tools justify-content-center">
                                        <span class="example-toggle" data-toggle="tooltip" title=""
                                            data-original-title="View code"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <form method="POST" enctype="multipart/form-data" id="blog-post" action="javascript:void(0)" >
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <h6>Blog Title</h6>
                                            <input type="text" class="form-control" placeholder="Enter Blog Title"
                                                name="title" id="title">
                                        <span id="title_error"></span>

                                            
                                        </div>

                                        <h6>Featured Image</h6>
                                        
                                        <div class="dropzone dropzone-default" id="kt_dropzone_1">
                                            <div class="dropzone-msg dz-message needsclick">
                                                <h3 class="dropzone-msg-title">Drop files here or click to upload.</h3>
                                                <span class="dropzone-msg-desc"><img id="image_preview_container" src="" alt="preview image" style="max-height: 150px;">
                                                    </span>
                                            </div>
                                        </div>
                                        <span class="form-text text-muted">Max file size is 5MB.</span>
                                            
                            
                                            <input type="file" id="image" name="image" />
                                        <span id="image_error"></span>

                                    </div>
                                    <div class="col-sm-6">
                                        <h6>Blog Content</h6>
                                        <textarea class="ckeditor" name="description" id="description"></textarea>
                                        <span id="description_error"></span>
                                        {{-- class="ckeditor" --}}
                                    </div>
                                    <div class="col-sm-6">
                                        <h6>Category</h6>
                                        <select id="category_id" name="category_id">
                                            @foreach ($categories as $category)
                                                <option value="{{ $category->id }}">{{ $category->title }}</option>
                                            @endforeach
                                        </select>
                                        <span id="category_id_error"></span>

                                    </div>
                                    <div class="col-sm-6">
                                        <h6>Category</h6>
                                        <select id="status" name="status">
                                                <option value="draft">Draft</option>
                                                <option value="published">Publish</option>
                                        </select>
                                        <span id="category_id_error"></span>

                                    </div>
                                </div>
                                <div class="text-left mt-5"><button href="" type="submit" class="btn btn-primary">Submit</button></div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>

                <!--begin::Row-->
                <div class="row">
                    @foreach ($blogs as $blog)
                    <div class="col-xl-4">
                        <!--begin::Mixed Widget 10-->
                        <div class="card card-custom card-stretch gutter-b">

                            <!--begin::Body-->
                            <div class="card-body d-flex flex-column">
                                <div class="flex-grow-1 pb-5">
                                    <div class="bgi-no-repeat bgi-size-cover rounded min-h-265px mb-4"
                                        style="background-image: url({{ asset('img/large/' .$blog->image) }})"></div>
                                    <!--begin::Link-->
                                    <a href="{{ URL::to('blog/'.$blog->slug) }}" class="text-dark font-weight-bolder text-hover-primary font-size-h4">{{ $blog->title }}
                                    </a>
                                    <!--end::Link-->
                                    <!--begin::Desc-->
                                    <p class="text-dark-50 font-weight-normal font-size-lg mt-6">{{ strip_tags(substr($blog->description,0,150)) }}</p>
                                    <div class="font-size-sm text-muted mt-2">{{ $blog->created_at->diffForHumans() }}</div>
                                    <!--end::Desc-->
                                    <!--begin::Action-->
                                    <div class="d-flex align-items-center">
                                        <a href="{{ URL::to('blog/'.$blog->slug) }}"
                                            class="btn btn-hover-text-primary btn-hover-icon-primary btn-sm btn-text-dark-50 bg-light-primary rounded font-weight-bolder font-size-sm p-2 mr-2">
                                            <span class="svg-icon svg-icon-md svg-icon-primary pr-2">
                                                <!--begin::Svg Icon | path:/assets/media/svg/icons/Communication/Group-chat.svg-->
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px"
                                                    viewBox="0 0 24 24" version="1.1">
                                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                        <rect x="0" y="0" width="24" height="24"></rect>
                                                        <path
                                                            d="M16,15.6315789 L16,12 C16,10.3431458 14.6568542,9 13,9 L6.16183229,9 L6.16183229,5.52631579 C6.16183229,4.13107011 7.29290239,3 8.68814808,3 L20.4776218,3 C21.8728674,3 23.0039375,4.13107011 23.0039375,5.52631579 L23.0039375,13.1052632 L23.0206157,17.786793 C23.0215995,18.0629336 22.7985408,18.2875874 22.5224001,18.2885711 C22.3891754,18.2890457 22.2612702,18.2363324 22.1670655,18.1421277 L19.6565168,15.6315789 L16,15.6315789 Z"
                                                            fill="#000000"></path>
                                                        <path
                                                            d="M1.98505595,18 L1.98505595,13 C1.98505595,11.8954305 2.88048645,11 3.98505595,11 L11.9850559,11 C13.0896254,11 13.9850559,11.8954305 13.9850559,13 L13.9850559,18 C13.9850559,19.1045695 13.0896254,20 11.9850559,20 L4.10078614,20 L2.85693427,21.1905292 C2.65744295,21.3814685 2.34093638,21.3745358 2.14999706,21.1750444 C2.06092565,21.0819836 2.01120804,20.958136 2.01120804,20.8293182 L2.01120804,18.32426 C1.99400175,18.2187196 1.98505595,18.1104045 1.98505595,18 Z M6.5,14 C6.22385763,14 6,14.2238576 6,14.5 C6,14.7761424 6.22385763,15 6.5,15 L11.5,15 C11.7761424,15 12,14.7761424 12,14.5 C12,14.2238576 11.7761424,14 11.5,14 L6.5,14 Z M9.5,16 C9.22385763,16 9,16.2238576 9,16.5 C9,16.7761424 9.22385763,17 9.5,17 L11.5,17 C11.7761424,17 12,16.7761424 12,16.5 C12,16.2238576 11.7761424,16 11.5,16 L9.5,16 Z"
                                                            fill="#000000" opacity="0.3"></path>
                                                    </g>
                                                </svg>
                                                <!--end::Svg Icon-->
                                            </span>{{ $blog->comment_count }}</a>
                                        <a href="#"
                                            class="btn btn-hover-text-danger btn-hover-icon-danger btn-sm btn-text-dark-50 bg-hover-light-danger rounded font-weight-bolder font-size-sm p-2">
                                            <span class="svg-icon svg-icon-md svg-icon-dark-25 pr-1">
                                                <!--begin::Svg Icon | path:/assets/media/svg/icons/General/Heart.svg-->
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px"
                                                    viewBox="0 0 24 24" version="1.1">
                                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                        <polygon points="0 0 24 0 24 24 0 24"></polygon>
                                                        <path
                                                            d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                                                            fill="#000000" fill-rule="nonzero"></path>
                                                    </g>
                                                </svg>
                                                <!--end::Svg Icon-->
                                            </span>{{ $blog->likers()->count() }}</a>
                                    </div>
                                    <!--end::Action-->
                                </div>
                                <!--begin::Team-->

                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Mixed Widget 10-->
                    </div>
                    <!-- end : col-4 -->
                    @endforeach

                </div>
                <!--end::Row-->
                @if ($blogs->total() > 12)
                <div class="row">
                    <div class="col-12">
                        <div class="card card-custom gutter-b">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center flex-wrap">
                                    {{ $blogs->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                <!--end::Dashboard-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Entry-->
    </div>
    <!--end::Content-->

@endsection
@section('js')
<script src="{{ asset('assets/plugins/custom/uppy/uppy.bundle.js?v=7.1.2') }}"></script>
<script src="{{ asset('assets/js/pages/crud/file-upload/uppy.js?v=7.1.2') }}"></script>
<script src="//cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
<script>

    $('.submit-btn').click(function(){
        var category_id = $('#category_id').val();
        var description = $('#description').val();
        var $title = $('#title').val();
        var $image = $('#image').val();
                if (title != "" ) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'post',
                        url: APP_URL + '/blog/update',
                        data: {
                            category_id: category_id,
                            description: description,
                            title: title,
                            image: image,
                        },
                        success: function(response) {
                            if (response.status) {
                                swal("Thankyou!",
                                response.msg,
                                    "success");
                                if (response.msg=="Removed Flag"){
                                    $current.html('<i class="fa fa-flag text-medium"></i>'); 
                                }
                                else{
                                    $current.html('<i class="fa fa-flag text-danger"></i>'); 
                                }
                            } else {
                                swal("Oops!", "Something went wrong, Please try again", "warning");
                            }
                        },
                        error: function(response) {
                            swal("Oops!", "Something went wrong, Please try again", "warning");
                        }
                    });
                }
            return false;
        });

        $(document).ready(function (e) {
  
  $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
  });

  $('#image').change(function(){
    
      let reader = new FileReader();
      reader.onload = (e) => { 
        $('#image_preview_container').attr('src', e.target.result); 
        $('.dropzone-msg-title').hide();
      }
      reader.readAsDataURL(this.files[0]); 

  });

  $('#blog-post').submit(function(e) {
      e.preventDefault();
      for (instance in CKEDITOR.instances) 
        {
            CKEDITOR.instances[instance].updateElement();
        }
      var formData = new FormData(this);
      $.ajax({
          type:'POST',
          url: APP_URL + '/blog/save',
          data: formData,
          cache:false,
          contentType: false,
          processData: false,
          success: (data) => {
              this.reset();
              alert('Image has been uploaded successfully');
          },
          error: function (reject) {
                var errors = $.parseJSON(reject.responseText);
                $.each(errors.errors, function (key, val) {
                    console.log(key + " - - " + val );
                    $("#" + key + "_error").text(val);
                });
                }
      });
  });
});
</script>
@endsection
