		<!-- Top Bar
		============================================= -->
		<div class="position-relative">
		<div id="top-bar" class="top-bar">
			<div class="container clearfix">
			
			<div class="row justify-content-between">	

					<div class="col-12 px-0 d-md-block d-lg-none">
						<div class="d-flex justify-content-center">
						<!-- Top Links
						============================================= -->
						<div class="top-links">
							<ul class="top-links-container">
								<li class="top-links-item"><a href="#">Become a Member</a></li> 
								<li class="top-links-item d-none d-sm-inline-block"><a href="#"><i class="icon-download-alt"></i> Download App</a></li>
							</ul>
						</div><!-- .top-links end -->

						<ul id="top-social" class="d-md-none d-none d-lg-block">
							<li><a href="#" target="_blank" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span></a></li>
							<li><a href="#" target="_blank" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span></a></li>
							<li><a href="#" target="_blank" class="si-instagram"><span class="ts-icon"><i class="icon-instagram2"></i></span></a></li>
							<li><a href="#" target="_blank" class="si-linkedin"><span class="ts-icon"><i class="icon-linkedin"></i></span></a></li>
							<li><a href="#" target="_blank" class="si-quora"><span class="ts-icon"><i class="icon-quora"></i></span></a></li>
							<li><a href="tel:+91 9999999999" class="si-call"><span class="ts-icon"><i class="icon-call"></i></span><span class="ts-text">+91 9898989898</span></a></li>
							<li><a href="mailto:info@finest50.com" class="si-email3"><span class="ts-icon"><i class="icon-envelope-alt"></i></span><span class="ts-text">info@finest50.com</span></a></li>
						</ul><!-- #top-social end -->

						<?php if(auth()->guard()->guest()): ?>
							<a href="<?php echo e(route('login')); ?>"><div class="btn login-btn mobile-btn"><?php echo e(__('Login')); ?></div></a>
						<?php else: ?>
							<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
								<div class="btn login-btn mobile-btn">
									<?php echo e(__('Logout')); ?>

								</div>
							</a>
							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo csrf_field(); ?>
							</form>
						<?php endif; ?>
						</div>

					</div>	

					<div class="col-12 col-lg-3 px-0">
						<div id="primary-menu-trigger">
							<svg class="svg-trigger" viewBox="0 0 100 100"><path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path><path d="m 30,50 h 40"></path><path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path></svg>
						</div>

						<!-- Primary Navigation
						============================================= -->
						<nav class="primary-menu with-arrows">

							<ul class="menu-container">
								<li class="menu-item"><a class="menu-link" href="#" class="pl-0"><div><i class="icon-line-grid"></i>All Categories</div></a>
									<ul class="sub-menu-container">
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('members/'. $category->slug)); ?>"><div><i class="icon-line2-user"></i><?php echo e($category->title); ?></div></a>
											<?php if(count($category->children)>0): ?>
											<ul class="sub-menu-container">
												
												<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('members/'. $child->slug)); ?>"><div> <?php echo e($child->title); ?></div></a></li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
											<?php endif; ?>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>
							</ul>

						</nav><!-- #primary-menu end -->
					</div>

					<div class="col-12 col-lg-6 px-0 d-md-none d-none d-lg-block">
						<div class="d-flex justify-content-center">
						<!-- Top Links
						============================================= -->
						<div class="top-links">
							<ul class="top-links-container">
								<li class="top-links-item"><a href="#">Become a Member</a></li> 
								<li class="top-links-item d-none d-sm-inline-block"><a href="#"><i class="icon-download-alt"></i> Download App</a></li>
							</ul>
						</div><!-- .top-links end -->

						<ul id="top-social">
							<li><a href="#" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span></a></li>
							<li><a href="#" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span></a></li>
							<li><a href="#" class="si-instagram"><span class="ts-icon"><i class="icon-instagram2"></i></span></a></li>
							<li><a href="#" class="si-linkedin"><span class="ts-icon"><i class="icon-linkedin"></i></span></a></li>
							<li><a href="#" class="si-quora"><span class="ts-icon"><i class="icon-quora"></i></span></a></li>
							<li><a href="tel:+91 9999999999" class="si-call"><span class="ts-icon"><i class="icon-call"></i></span><span class="ts-text">+919898989898</span></a></li>
							<li><a href="mailto:info@finest50.com" class="si-email3"><span class="ts-icon"><i class="icon-envelope-alt"></i></span><span class="ts-text">info@finest50.com</span></a></li>
						</ul><!-- #top-social end -->
						</div>

					</div>

					<div class="col-12 col-lg-3 px-0">

						<!-- <a href="login.php"><div class="btn login-btn desktop-btn">Login</div></a> -->
						<?php if(auth()->guard()->guest()): ?>
							<a href="<?php echo e(route('login')); ?>"><div class="btn login-btn desktop-btn"><?php echo e(__('Login')); ?></div></a>
						<?php else: ?>
							<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
								<div class="btn login-btn desktop-btn">
									<?php echo e(__('Logout')); ?>

								</div>
							</a>
							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo csrf_field(); ?>
							</form>
						<?php endif; ?>
						<div class="second-menu">
						<nav class="primary-menu with-arrows">

							<ul class="menu-container">
								<li class="menu-item"><a class="menu-link hide-icon-angle-down" href="#" class="pl-0"><div><i class="icon-line-menu"></i> Menu</div></a>
									<ul class="sub-menu-container">
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/')); ?>"><div><i class="icon-line2-home"></i>Home</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('about')); ?>"><div><i class="icon-line2-info"></i>About Us</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/members')); ?>"><div><i class="icon-line2-users"></i>Members</div></a>
											
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/blogs')); ?>"><div><i class="icon-line2-support"></i>Stories</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/faq')); ?>"><div><i class="icon-line2-question"></i>FAQs</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/partners')); ?>"><div><i class="icon-handshake1"></i>Partners</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/questions')); ?>"><div><i class="icon-line2-question"></i>Q&A</div></a>
										</li>
										<li class="menu-item"><a class="menu-link" href="<?php echo e(URL::to('/contact')); ?>"><div><i class="icon-line2-screen-smartphone"></i>Contact Us</div></a>
										</li>
										
									</ul>
								</li>
							</ul>

						</nav><!-- #primary-menu end -->

					</div>
					</div>	


				</div>

			</div>
		</div>
	</div><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/layout/partials/home-header.blade.php ENDPATH**/ ?>