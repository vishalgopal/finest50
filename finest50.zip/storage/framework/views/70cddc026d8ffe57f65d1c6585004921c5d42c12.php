<!-- Stylesheets
	============================================= -->
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css?family=Istok+Web:400,700&amp;display=swap" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css" />

	<!-- <link rel="stylesheet" href="css/dark.css" type="text/css" /> -->
	<link rel="stylesheet" href="<?php echo e(asset('css/font-icons.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>" type="text/css" />

	<!-- Hosting Demo Specific Stylesheet -->
	<!-- <link rel="stylesheet" href="css/course.css" type="text/css" /> -->
	<!-- / -->

	<link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?> " type="text/css" >
	<!-- custom css -->
	<link rel="stylesheet" href="<?php echo e(asset('css/custom-2.css')); ?>" type="text/css" /><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/layout/partials/css.blade.php ENDPATH**/ ?>