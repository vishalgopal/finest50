<?php $__env->startSection('content'); ?>

<section id="content" class="loginpage">
    <div class="content-wrap">
        <div class="container-fluid" style="max-width: 850px;">

            <div class="row">

                <div class="col-lg-5 login-right card">
                    <img src="<?php echo e(asset('images/login2.svg')); ?>" alt="Login">
                    <h3>Welcome to Finest 50</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit ipsum dolor sit amet.</p>

                </div>

                <div class="col-12 col-lg-7 mb-0 login-left">
                    <div class="card mb-0">
                        <div class="card-body" style="padding: 40px;">
                            <form id="login-form" method="POST" action="<?php echo e(route('login')); ?>"
                                name="login-form" class="mb-0" action="#" method="post">
                                <?php echo csrf_field(); ?>
                                <h3><?php echo e(__('Login')); ?> to your Account</h3>

                                <div class="row">
                                    <div class="col-12 form-group">
                                        <label
                                            for="login-form-username"><?php echo e(__('E-Mail Address')); ?>:</label>
                                        <input id="email" type="email"
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                            value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                            autofocus>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 form-group">
                                        <label for="login-form-password"><?php echo e(__('Password')); ?>:</label>
                                        <input id="password" type="password"
                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                            required autocomplete="current-password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 form-group float-right">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                            <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="remember">
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                    </div>

                                    <div class="col-12 form-group">
                                        <button class="button button-3d button-primary m-0" id="login-form-submit"
                                            name="login-form-submit" type="submit"
                                            value="login"><?php echo e(__('Login')); ?></button>
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="btn btn-link"
                                                href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Forgot Your Password?')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>

                                    <div class="divider my-3 divider-rounded divider-center">&nbsp;&nbsp;or&nbsp;&nbsp;
                                    </div>

                                    <div class="login-btns form-group">
                                        <a href="<?php echo e(route('social.oauth', 'google')); ?>" class="btn btn-outline-dark"><img
                                                src="<?php echo e(asset('images/login/gmail.svg')); ?>">Log
                                            in with Google</a>

                                        <a href="<?php echo e(route('social.oauth', 'facebook')); ?>" class="btn btn-outline-dark"><img
                                                src="<?php echo e(asset('images/login/facebook.svg')); ?>">Log
                                            in with Facebook</a>

                                    </div>
                                    <div class="login-btns form-group">
                                        <a href="<?php echo e(route('social.oauth', 'linkedin')); ?>" class="btn btn-outline-dark"><img
                                                src="<?php echo e(asset('images/login/linkedin.svg')); ?>">Log
                                            in with LinkedIn</a>

                                        <a href="<?php echo e(route('social.oauth', 'twitter')); ?>" class="btn btn-outline-dark"><img
                                                src="<?php echo e(asset('images/login/twitter.svg')); ?>">Log
                                            in with Twitter</a>

                                    </div>

                                    <div class="divider my-3"></div>

                                    <div class="col-12 form-group">
                                        New to Finest 50? <a href="<?php echo e(route('register')); ?>"
                                            onclick="">Create account</a>
                                    </div>

                                </div>

                            </form>
                        </div>
                    </div>


                </div>

            </div>
            <!-- row end -->

        </div>
    </div>
</section><!-- #content end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/auth/login.blade.php ENDPATH**/ ?>