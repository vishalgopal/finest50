<?php $__env->startSection('content'); ?>
<?php if(\Auth::check()): ?>
    <script>window.location = "<?php echo e(URL::to('/')); ?>";</script>
<?php endif; ?>

<section id="content" class="loginpage">
    <div class="content-wrap">
        <div class="container-fluid" style="max-width: 850px;">

            <div class="row">

                <div class="col-lg-5 login-right card">
                    <img src="images/login2.svg" alt="Login">
                <h3>Welcome to Finest 50</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit ipsum dolor sit amet.</p>

                </div>

                <div class="col-12 col-lg-7 mb-0 login-left">
                    <div class="card mb-0">
                        <div class="card-body" style="padding: 40px;">
                            <h3><?php echo e(__('Login')); ?></h3>

                            <form id="login-form" name="login-form" class="row mb-0" method="POST"
                            onsubmit="return registerpage();">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 form-group">
                                    <label for="email"
                                        class=""><?php echo e(__('E-Mail Address')); ?></label>

                                    <input id="email" type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                        value="<?php echo e(old('email')); ?>" autocomplete="email" data-parsley-type="email" data-parsley-trigger="change">
                                        <span id="email_error"></span> 
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="divider my-3 divider-rounded divider-center">&nbsp;&nbsp;or&nbsp;&nbsp;
                                </div>

                                <div class="col-12 form-group">
                                    <label for="mobile"
                                        class="">Mobile </label>

                                    <input id="phone" type="tel"
                                        class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile"
                                        value="<?php echo e(old('mobile')); ?>" autocomplete="phone" data-parsley-pattern="^[6-9]\d{9}$">
                                        <span id="mobile_error"></span>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 form-group">
                                    <button class="button button-3d button-primary m-0" id="login-form-submit"
                                        name="login-form-submit" value="register" type="submit">Login</button>
                                </div>

                                <div class="divider my-3 divider-rounded divider-center">&nbsp;&nbsp;or&nbsp;&nbsp;
                                </div>

                                <div class="login-btns form-group">
                                    <a href="<?php echo e(route('social.oauth', 'google')); ?>" class="btn btn-outline-dark"><img
                                            src="<?php echo e(asset('images/login/gmail.svg')); ?>">Log
                                        in with Google</a>

                                    <a href="<?php echo e(route('social.oauth', 'facebook')); ?>" class="btn btn-outline-dark"><img
                                            src="<?php echo e(asset('images/login/facebook.svg')); ?>">Log
                                        in with Facebook</a>

                                </div>
                                <div class="login-btns form-group">
                                    <a href="<?php echo e(route('social.oauth', 'linkedin')); ?>" class="btn btn-outline-dark"><img
                                            src="<?php echo e(asset('images/login/linkedin.svg')); ?>">Log
                                        in with LinkedIn</a>

                                    <a href="<?php echo e(route('social.oauth', 'twitter')); ?>" class="btn btn-outline-dark"><img
                                            src="<?php echo e(asset('images/login/twitter.svg')); ?>">Log
                                        in with Twitter</a>

                                </div>

                                <div class="divider my-3"></div>

                                <div class="col-12 form-group">
                                    New to Finest 50? <a href="<?php echo e(route('signup')); ?>">Create account</a>
                                </div>

                            </form>

                            
                            <form id="otp-form" name="otp-form" class="row mb-0" method="POST"
                            onsubmit="return verifyotp();" style="display:none">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 form-group">
                                    <label for="otp"
                                        class="">OTP</label>
                                    <input id="otp" type="text"
                                        class="form-control <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otp"
                                        value="<?php echo e(old('otp')); ?>" required
                                        autofocus>
                                    <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 form-group">

                                    Resend OTP <a href="javascript:resendotp();">Resend</a>
                                </div>

                                <div class="col-12 form-group">
                                    <button class="button button-3d button-primary m-0" id="otp-form-submit"
                                        name="otp-form-submit" value="otp" type="submit">Verify</button>
                                </div>

                                <div class="divider my-3"></div>

                                

                            </form>
                            

                        </div>
                    </div>


                </div>

            </div>
            <!-- row end -->

        </div>
    </div>
</section><!-- #content end -->
<!-- Ends -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    var uid=0;
    var redirectto = "<?php echo e(url()->previous()); ?>";
    $(function() {
        $('#login-form').parsley();
    });

    function registerpage() {
        if ($('#login-form').parsley().validate()) {
            var mobile = $("#phone").val();
            var email = $("#email").val();

            if ( email != "" || mobile != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'post',
                    url: 'signin',
                    data: {
                        email: email,
                        mobile: mobile
                    },
                    success: function(response) {
                        if (response.status) {
                            $('#otp-form').show();
                            $('#login-form').hide();
                            uid=response.id;
                            console.log("uid - "+ uid);
                        } else {
                            
                            swal("Oops!", response.msg, "warning");
                        }
                    },
                    error: function (reject) {
                            var errors = $.parseJSON(reject.responseText);
                            console.log(errors);
                            $.each(errors.error, function (key, val) {
                                console.log("errors  - ");
                                console.log(key + " - - " + val[0] );

                                $("#" + key + "_error").text(val[0]);
                            });
                    }
                });
            }
            else{
            swal("Oops!", "Enter Mobile or Email",
                    "warning");
                }
        }
        return false;
    }
    function resendotp() {
            if (uid != "" ) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'post',
                    url: 'resendotp',
                    data: {
                        uid: uid,
                    },
                    success: function(response) {
                        console.log(response); 
                        if (response.status) {
                            swal("OTP Sent!", "OTP resent", "success");
                        } else {
                            swal("Oops!", "Wrong OTP, Please try again", "warning");
                        }
                    }
                });
            }
            else{
            swal("Oops!", "Something is not right",
                    "warning");
                }
        return false;
    }
</script>
<?php $__env->stopSection(); ?> 
<!-- register  -->

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/auth/login-otp.blade.php ENDPATH**/ ?>