
<!DOCTYPE html>
<html lang="en">
	<!--begin::Head-->
	<head><base href="">
        <meta charset="utf-8" />
            <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Finest 50')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->yieldContent('meta'); ?>
        <?php echo $__env->make('layout.partials.dashboard.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('css'); ?>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="header-fixed header-mobile-fixed subheader-enabled page-loading">
        <?php echo $__env->make('layout.partials.dashboard.mobile-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!--begin::Main-->	
		<div class="d-flex flex-column flex-root">
			<!--begin::Page-->
			<div class="d-flex flex-row flex-column-fluid page">
                <?php echo $__env->make('layout.partials.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<!--begin::Wrapper-->
				<div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">

					<!--begin::Header-->
					<div id="kt_header" class="header bg-white header-fixed">
						<!--begin::Container-->
						<div class="container-fluid d-flex align-items-stretch justify-content-between">
							<!--begin::Left-->
							<div class="d-flex align-items-stretch mr-2">
								<!--begin::Page Title-->
								<h3 class="d-none text-dark d-lg-flex align-items-center mr-10 mb-0">Dashboard</h3>
								<!--end::Page Title-->
                    <?php echo $__env->make('layout.partials.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					

					</div>
						<!--end::Container-->
					</div>
					<!--end::Header-->

					<?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('layout.partials.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
				</div>
				<!--end::Wrapper-->
			</div>
			<!--end::Page-->
		</div>
		<!--end::Main-->
		


        <?php echo $__env->make('layout.partials.dashboard.user-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.partials.dashboard.chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.partials.dashboard.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('js'); ?>
	</body>
	<!--end::Body-->
</html><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/layout/dashboard.blade.php ENDPATH**/ ?>