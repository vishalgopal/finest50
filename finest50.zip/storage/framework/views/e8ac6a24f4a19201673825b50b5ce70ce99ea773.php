

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
	<!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid pt-10" id="kt_content">						
						
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Dashboard-->
                
                <!--begin::Row-->
                <div class="row">
                    <div class="col-12">
                <!--begin::Items-->
                <div class="card card-custom gutter-b card-stretch">
                    <div class="card-body d-flex flex-row">
                                <div class="row w-100">
                                    <!--begin::Item-->
                                    <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3 col-6 d-flex align-items-center justify-content-between mb-5">
                                        <div class="d-flex align-items-center mr-2">
                                            <div class="symbol symbol-50 symbol-light mr-3 flex-shrink-0">
                                                <div class="symbol-label">
                                                    <img src="<?php echo e($follower->avatar); ?>" alt="<?php echo e($follower->name); ?>" class="h-75" />
                                                </div>
                                            </div>
                                            <div>
                                                <a href="#" class="font-size-h6 text-dark-75 text-hover-primary font-weight-bolder"><?php echo e($follower->name); ?></a>
                                                <div class="font-size-sm text-muted font-weight-bold mt-1"><?php echo e($follower->created_at->diffForHumans()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!--end::Item-->
                                </div>
                                <!--end::Items-->
                <!--end::Row-->
                    </div>
                </div>
                </div>
                </div>

                <!--end::Dashboard-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Entry-->
    </div>
    <!--end::Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/dashboard/followers.blade.php ENDPATH**/ ?>