

<?php $__env->startSection('title'); ?>
    Search - <?php echo e($query); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title
          ============================================= -->
    
    <!-- #page-title end -->

    <!-- Content ============================================= -->
    <section id="content">
        <div class="content-wrap">

            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">

                    <!-- Post Content   ============================================= -->
                    <div class="postcontent col-12">
						<?php if(count($users)>0): ?>
                        <div class="page-title">
                            <h2>Members</h2>
                            <a href="<?php echo e(URL::to('search/member/'.$query)); ?>">
                                <div class="btn btn-follow mt-0">View All</div>
                            </a>
                        </div>
						<?php endif; ?>
                        <!-- search ============================================= -->
                        <div id="" class="shop row" data-layout="fitRows">

                            <div class="container">
								<?php if(count($users)>0): ?>
                                <div class="row">
                                    <div class="col-12">
                                        <!-- carousel begin -->
                                        <div class="owl-carousel owl-carousel-full image-carousel carousel-widget search-all-members"
                                            data-center="false" data-loop="false" data-autoplay="5000" data-nav="true"
                                            data-pagi="true" data-items-xs="2" data-items-sm="2" data-items-md="3"
                                            data-items-lg="3" data-items-xl="5">
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="oc-item">
                                                    <div
                                                        class="feature-box hover-effect shadow-sm fbox-center fbox-bg fbox-light fbox-lg fbox-effect">
                                                        <div class="fbox-icon"><a href="<?php echo e(URL::to('search/member/' . $user->slug)); ?>">
                                                            <i><img src="<?php echo e($user->avatar); ?>"
                                                                    class="border-0 bg-transparent shadow-sm"
                                                                    style="z-index: 2;" alt="<?php echo e($user->name); ?>"></i>
                                                                    </a>
                                                        </div>
                                                        <div class="fbox-content">
                                                            <h3 class="mb-4 nott ls0"><a href="<?php echo e(URL::to('search/member/' . $user->slug)); ?>"
                                                                    class="text-dark"><?php echo e($user->name); ?></a></h3>
                                                            <p><small
                                                                    class="subtitle nott color"><?php echo e($user->designation); ?></small>
                                                            </p>

                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <!-- carousel end -->
                                    </div>
                                </div>
                                <!-- members end -->

                                <div class="divider"><i class="icon-circle"></i></div>

								<?php endif; ?>
								<?php if(count($categories)>0): ?>
                                <div class="page-title">
                                    <h2>Categories</h2>
                                    <a href="<?php echo e(URL::to('members/'.$query)); ?>">
                                        <div class="btn btn-follow mt-0">View All</div>
                                    </a>
                                </div>
								<?php endif; ?>
								<!-- Posts ============================================= -->
								<?php if(count($categories)>0): ?>
                                <div id="posts" class="blog-search  course-categories  post-grid row grid-container gutter-40 clearfix"
                                    data-layout="fitRows">

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-2 col-sm-3 col-6 mt-4">
                                                <div class="card hover-effect">
                                                    <img class="card-img" src="<?php echo e(asset('img/small/' . $category->image )); ?>" alt="<?php echo e($category->title); ?>">
                                                    <a href="<?php echo e(URL::to('/members/' . $category->slug)); ?>" class="card-img-overlay rounded p-0"
                                                        style="background-color: rgba(<?php echo e(rand(1, 251)); ?>,<?php echo e(rand(1, 251)); ?>,<?php echo e(rand(1, 251)); ?>,0.8);">
                                                        <span><i class="icon-music1"></i><?php echo e($category->title); ?></span>
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								
                                <!-- Blogs end -->

                                <div class="divider"><i class="icon-circle"></i></div>
                                <?php endif; ?>
                                <?php if(count($blogs)>0): ?>
                                <div class="page-title">
                                    <h2>Blogs</h2>
                                    <a href="<?php echo e(URL::to('search/blog/'.$query)); ?>">
                                        <div class="btn btn-follow mt-0">View All</div>
                                    </a>
                                </div>
								<?php endif; ?>
								<!-- Posts ============================================= -->
								<?php if(count($blogs)>0): ?>
                                <div id="posts" class="blog-search post-grid row grid-container gutter-40 clearfix"
									data-layout="fitRows">
									
									<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="entry col-md-3 col-sm-6 col-6">
                                        <div class="grid-inner">
                                            <div class="entry-image">
                                                <a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>" ><img
                                                        src="<?php echo e(asset('img/large/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"></a>
                                            </div>
                                            <div class="entry-title">
                                                <h2><a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>"><?php echo e($blog->title); ?></a></h2>
                                            </div>
                                            <div class="entry-meta">
                                                <ul>
                                                    <li><i class="icon-calendar3"></i> <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('M d, Y')); ?></li>
                                                    <li><a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>#comments"><i class="icon-comments"></i>
                                                            <?php echo e($blog->comment_count); ?></a></li>
                                                </ul>
                                            </div>
                                            <div class="entry-content">
                                                <p><?php echo e(strip_tags(substr($blog->description,0,180))); ?></p>
                                                <a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>" class="more-link">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                    
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								
                                <!-- Blogs end -->

                                <div class="divider"><i class="icon-circle"></i></div>
								<?php endif; ?>
								<?php if(count($questions)>0): ?>
                                <div class="page-title">
                                    <h2>Popular Q&A</h2>
                                    <a href="<?php echo e(URL::to('search/question/'.$query)); ?>">
                                        <div class="btn btn-follow mt-0">View All</div>
                                    </a>
                                </div>
								
								
                                <div class="posts-sm row col-mb-30" id="popular-post-list-sidebar">
									<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
									<div class="entry col-12">
                                        <div class="grid-inner row no-gutters">
                                            <div class="col-auto">
                                                <div class="entry-image">
                                                </div>
                                            </div>
                                            <div class="col pl-3">
                                                <div class="entry-title">
                                                    <h4><a href="<?php echo e(URL::to('question/' . $question->slug)); ?>"><?php echo e($question->title); ?></a></h4>
                                                </div>
                                                <div class="entry-meta">
                                                    <ul>
                                                        <li><i class="icon-comments-alt"></i> <?php echo e($question->answers_count); ?> Answers</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- q and a end -->
							</div>
							<?php endif; ?>
                        </div>
                        <?php if(count($users)==0 && count($categories)==0 && count($blogs)==0 && count($questions)==0): ?> 
                        No Results Found!!
                        <?php endif; ?>

                    </div><!-- #search end -->


                </div><!-- .postcontent end -->


            </div>

        </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="js/jquery.matchHeight-min.js"></script>
    <script>
        $(function() {
            $('.feature-box').matchHeight();
            $('.search-all-members .fbox-content h3').matchHeight();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/search/all.blade.php ENDPATH**/ ?>