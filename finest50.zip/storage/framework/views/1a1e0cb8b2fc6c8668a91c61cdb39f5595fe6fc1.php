

<?php $__env->startSection('title'); ?>
    Search - <?php echo e($query); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title
          ============================================= -->
    <section class="search-title">
        <div class="container clearfix">
            <div class="col-md-8 offset-md-2">
                <div class="shadow">

                    <div class="input-group input-group-lg mt-1 home-searchbar">
                        <!-- desktop-category -->
                        <div class="form-group mb-0 category-select d-none d-lg-block">
                            <select id="single" class="form-control select2-single">
                                <option value="all">All</option>
                                <option value="member">Member</option>
                                <option value="blog">Blog</option>
                                <option value="question">Question</option>
                            </select>
                        </div>
                        <!-- / -->

                        <input class="form-control rounded border-0 main-search cd-search-trigger" type="search"
                            placeholder="Search ends here.." aria-label="Search">

                        <!-- mobile-category -->
                        <div class="form-group mb-0 category-select d-block d-lg-none">
                            <select id="single" class="form-control select2-single">
                                <option value="all">All</option>
                                <option value="member">Member</option>
                                <option value="blog">Blog</option>
                                <option value="question">Question</option>
                            </select>
                        </div>
                        <!-- / -->

                        <div class="form-group mb-0">
                            <select id="single" class="form-control select2-single">
                                <option value="mu">Mumbai</option>
                                <option value="dh">Delhi</option>
                                <option value="pn">Pune</option>
                                <option value="ke">Kerala</option>
                            </select>
                        </div>
                        <div class="input-group-append search-btn">
                            <button class="btn" type="submit"><i class="icon-line-search font-weight-bold"></i></button>
                        </div>
                    </div>
                </div>

                <!-- suggestion  -->

                <div class="cd-search-suggestions mCustomScrollbar">
                    <ul>
                        <li><a href="#">Teacher</a><br>
                            <p><a href="#">in Members</a></p>
                            <p><a href="#">in Blog</a></p>
                        </li>
                        <li><a href="#">Teacher</a></li>
                        <li><a href="#">Teacher</a></li>
                        <li><a href="#">Teacher</a></li>
                    </ul>
                </div> <!-- .cd-search-suggestions -->


            </div>
        </div>
    </section>
    <!-- #page-title end -->

    <!-- Content ============================================= -->
    <section id="content">
        <div class="content-wrap">

            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">

                    <!-- Post Content   ============================================= -->
                    <div class="postcontent col-12">
						
								<?php if(count($blogs)>0): ?>
                                <div class="page-title">
                                    <h2>Blogs</h2>
                                </div>
								<?php endif; ?>
								<!-- Posts ============================================= -->
								<?php if(count($blogs)>0): ?>
                                <div id="posts" class="blog-search post-grid row grid-container gutter-40 clearfix"
									data-layout="fitRows">
									
									<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="entry col-md-3 col-sm-6 col-6">
                                        <div class="grid-inner">
                                            <div class="entry-image">
                                                <a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>" ><img
                                                        src="<?php echo e(asset('img/large/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"></a>
                                            </div>
                                            <div class="entry-title">
                                                <h2><a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>"><?php echo e($blog->title); ?></a></h2>
                                            </div>
                                            <div class="entry-meta">
                                                <ul>
                                                    <li><i class="icon-calendar3"></i> <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('M d, Y')); ?></li>
                                                    <li><a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>#comments"><i class="icon-comments"></i>
                                                            <?php echo e($blog->comment_count); ?></a></li>
                                                </ul>
                                            </div>
                                            <div class="entry-content">
                                                <p><?php echo e(strip_tags(substr($blog->description,0,180))); ?></p>
                                                <a href="<?php echo e(URL::to('blog/'. $blog->slug)); ?>" class="more-link">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                    
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								
                                <!-- Blogs end -->

                                <div class="divider"><i class="icon-circle"></i></div>
								<?php endif; ?>
								<?php echo e($blogs->withQueryString()->links()); ?>

                        </div>


                    </div><!-- #search end -->


                </div><!-- .postcontent end -->


            </div>

        </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="js/jquery.matchHeight-min.js"></script>
    <script>
        $(function() {
            $('.feature-box').matchHeight();
            $('.search-all-members .fbox-content h3').matchHeight();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/search/blogs.blade.php ENDPATH**/ ?>