

<?php $__env->startSection('title', 'Questions'); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content
                          ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">

                    <!-- Post Content
                              ============================================= -->
                    <div class="postcontent col-lg-8">
                        <div class="qpage-title border-bottom">
                            <h3>Latest Questions</h3>
                            <!-- tabs begin -->
                            <ul id="myTab2" class="nav nav-pills boot-tabs">
                                <li class="nav-item"><a class="nav-link border active" href="#latest-ques"
                                        data-toggle="tab">Latest
                                        Questions</a></li>
                                <li class="nav-item"><a class="nav-link border" href="#most-answered" data-toggle="tab">Most
                                        Answered</a></li>
                            </ul>
                        </div>
                        <div id="myTabContent2" class="tab-content">
                            <div class="tab-pane fade show active" id="latest-ques">
                                <?php $__currentLoopData = $latestQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="qlist">
                                        <h4>Q: <?php echo e($latestQuestion->title); ?></h4>
                                        <div class="comment-content clearfix float-right">
                                            <div class="comment-author">
                                                <span><?php echo e(Carbon\Carbon::parse($latestQuestion->created_at)->format('M d, Y - h:i A')); ?></span>
                                            </div>
                                        </div>
                                        <div class="btns">
                                            <span class="badge badge-light border"><?php echo e(count($latestQuestion->answers)); ?>

                                                answer(s)</span>
                                            <span class="badge badge-light border"><a
                                                    href="<?php echo e(URL::to('question/' . $latestQuestion->slug)); ?>">View</a></span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($latestQuestions->fragment('latest-ques')->links()); ?>

                            </div>
                            <div class="tab-pane fade" id="most-answered">
                                <?php $__currentLoopData = $mostAnswerQues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostAnswerQue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="qlist">
                                        <h4>Q: <?php echo e($mostAnswerQue->title); ?></h4>
                                        <div class="comment-content clearfix float-right">
                                            <div class="comment-author">
                                                <span><?php echo e(Carbon\Carbon::parse($mostAnswerQue->created_at)->format('M d, Y - h:i A')); ?></span>
                                            </div>
                                        </div>
                                        <div class="btns">
                                            <span class="badge badge-light border"><?php echo e(count($mostAnswerQue->answers)); ?>

                                                answer(s)</span>
                                            <span class="badge badge-light border"><a
                                                    href="<?php echo e(URL::to('question/' . $mostAnswerQue->slug)); ?>">View</a></span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($mostAnswerQues->fragment('most-answered')->links()); ?>

                            </div>
                        </div>
                        <!-- tab end -->

                        


                    </div><!-- .postcontent end -->

                    <!-- Sidebar
                              ============================================= -->
                    <div class="sidebar col-lg-4 d-block ">
                        <div class="sidebar-widgets-wrap related-que shadow-sm">

                            <div class="widget widget_links text-left qwidget">

                                <h4>Random Questions</h4>
                                <?php $__currentLoopData = $randomQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $randomQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><a href="<?php echo e(URL::to('question/'.$randomQuestion->slug )); ?>"><?php echo e($randomQuestion->title); ?></a></p>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                            </div>


                        </div>
                    </div><!-- .sidebar end -->


                </div>

            </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            var hash = window.location.hash;
            hash && $('ul.nav a[href="' + hash + '"]').tab('show');

            $('.nav-tabs a').click(function(e) {
                $(this).tab('show');
                var scrollmem = $('body').scrollTop();
                window.location.hash = this.hash;
                $('html,body').scrollTop(scrollmem);
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/qa/list.blade.php ENDPATH**/ ?>