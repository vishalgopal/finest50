<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="digitallyyours" />	
	<meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title><?php echo e(config('app.name', 'Finest 50')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo $__env->make('layout.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

	<?php if(Request::is('/')): ?>
        <?php echo $__env->make('layout.partials.home-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>	

    <?php echo $__env->yieldContent('content', 'It seems there is some problem in loading! We are fixing it. '); ?>

    <?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	</div><!-- #wrapper end -->
    <?php echo $__env->make('layout.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js'); ?>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/layout/main.blade.php ENDPATH**/ ?>