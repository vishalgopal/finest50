

<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="container clearfix">

					<div class="row gutter-40 col-mb-80">
						<!-- Post Content
						============================================= -->
						<div class="postcontent col-lg-9">

							<div class="single-post mb-0">

								<!-- Single Post
								============================================= -->
								<div class="entry clearfix">

									<!-- Entry Title
									============================================= -->
									<div class="entry-title">
										<h2><?php echo e($blog->title); ?></h2>
									</div><!-- .entry-title end -->

									<!-- Entry Meta
									============================================= -->
									<div class="entry-meta">
										<ul>
											<li><i class="icon-calendar3"></i>  <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('M d, Y')); ?></li>
											<li><a href="<?php echo e(URL::to('member/'.$blog->user->slug)); ?>"><i class="icon-user"></i> <?php echo e($blog->user->name); ?></a></li>
											
											<li><a href="#"><i class="icon-comments"></i> <?php echo e($blog->comment_count); ?> Comments</a></li>
											
										</ul>
									</div><!-- .entry-meta end -->

									<!-- Entry Image
									============================================= -->
									<div class="entry-image">
										<a href="#"><img src="<?php echo e(asset('img/original/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"></a>
									</div><!-- .entry-image end -->

									<!-- Entry Content
									============================================= -->
									<div class="entry-content mt-0">

										<?php echo $blog->description; ?>

										<!-- Post Single - Content End -->

										<!-- Tag Cloud
										============================================= -->
										

										<div class="clear"></div>

										<!-- Post Single - Share
										============================================= -->
										<div class="si-share border-0 d-flex justify-content-between align-items-center">
											<span>Share this Post:</span>
											<div>
											<a href="https://www.facebook.com/sharer.php?u=<?php echo e(URL::full()); ?>" class="social-icon si-borderless si-facebook">
													<i class="icon-facebook"></i>
													<i class="icon-facebook"></i>
												</a>
												<a href="https://twitter.com/share?url=<?php echo e(URL::full()); ?>&text=<?php echo e($blog->title); ?>" class="social-icon si-borderless si-twitter">
													<i class="icon-twitter"></i>
													<i class="icon-twitter"></i>
												</a>
												<a href="https://pinterest.com/pin/create/bookmarklet/?media=<?php echo e(asset('img/original/'. $blog->image)); ?>&url<?php echo e(URL::full()); ?>&description=<?php echo e($blog->title); ?>

												" class="social-icon si-borderless si-pinterest">
													<i class="icon-pinterest"></i>
													<i class="icon-pinterest"></i>
												</a>
												<a href="https://plus.google.com/share?url=<?php echo e(URL::full()); ?>" class="social-icon si-borderless si-gplus">
													<i class="icon-gplus"></i>
													<i class="icon-gplus"></i>
												</a>
												<a href="https://www.linkedin.com/shareArticle?url=<?php echo e(URL::full()); ?>&title=<?php echo e($blog->title); ?>" class="social-icon si-borderless si-linkedin">
													<i class="icon-linkedin"></i>
													<i class="icon-linkedin"></i>
												</a>
											</div>
										</div><!-- Post Single - Share End -->
										<!-- Post Single - Like
										============================================= -->
										<div class="si-share border-0 d-flex justify-content-between align-items-center">
											
											<?php if(Auth::user()): ?>
                                                        <?php if(Auth::user()->hasLiked($blog)): ?>
                                                            <?php if($blog->likers()->count() > 1): ?>
                                                                <span id="like-<?php echo e($blog->id); ?>">you and
                                                                    <?php echo e($blog->likers()->count() - 1); ?> more <i
                                                                        class="icon-thumbs-up"></i> this</span>
                                                            <?php else: ?>
                                                                <span id="like-<?php echo e($blog->id); ?>">you <i
                                                                        class="icon-thumbs-up"></i> this </span>
                                                            <?php endif; ?>
                                                            <button type="button" class="btn btn-sm btn-primary likebtn"
                                                                data-blogid="<?php echo e($blog->id); ?>"><i
                                                                    class="icon-thumbs-up"></i>
                                                                Like</button>
                                                        <?php else: ?>
                                                            <?php if($blog->likers()->count() > 0): ?>
                                                                <span
                                                                    id="like-<?php echo e($blog->id); ?>"><?php echo e($blog->likers()->count()); ?>

                                                                    <i class="icon-thumbs-up"></i></span>
                                                            <?php else: ?>
                                                                <span id="like-<?php echo e($blog->id); ?>">Be the first one to <i
                                                                        class="icon-thumbs-up"></i> this</span>
                                                            <?php endif; ?>
                                                            <button type="button"
                                                                class="btn btn-sm btn-outline-dark likebtn"
                                                                data-blogid="<?php echo e($blog->id); ?>"><i
                                                                    class="icon-thumbs-up"></i>
                                                                Like</button>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span id="like-<?php echo e($blog->id); ?>"><?php echo e($blog->likers()->count()); ?>

                                                            <i class="icon-thumbs-up"></i></span>
                                                        <a type="button" class="btn btn-sm btn-outline-dark"
                                                            href="<?php echo e(URL::to('login')); ?>"><i class="icon-thumbs-up"></i>
                                                            Like</a>
                                                    <?php endif; ?>
											<div>
											
											</div>
										</div><!-- Post Single - Like End -->

									</div>
								</div><!-- .entry end -->

								<!-- Post Navigation
								============================================= -->
								<div class="row justify-content-between col-mb-30 post-navigation">
									<div class="col-12 col-md-auto text-center">
										<?php if($prev): ?>
										<a href="<?php echo e(URL::to('blog/'. $prev->slug)); ?>">&lArr; <?php echo e($prev->title); ?></a>
										<?php endif; ?>
									</div>

									<div class="col-12 col-md-auto text-center">
										<?php if($next): ?>
										<a href="<?php echo e(URL::to('blog/'. $next->slug)); ?>"><?php echo e($next->title); ?> &rArr;</a>
										<?php endif; ?>
									</div>
								</div><!-- .post-navigation end -->

								<div class="line"></div>

								<!-- Post Author Info
								============================================= -->
								<div class="card">
									<div class="card-header"><strong>Posted by <a href="<?php echo e(URL::to('member/'.$blog->user->slug)); ?>"><?php echo e($blog->user->name); ?></a></strong></div>
									<div class="card-body">
										<div class="author-image">
											<img src="<?php echo e($blog->user->avatar); ?>" alt="Image" class="rounded-circle">
										</div>
										<?php echo e($blog->user->short_description); ?>

									</div>
								</div><!-- Post Single - Author End -->

								<div class="line"></div>

								<h4>Related Posts:</h4>

								<div class="related-posts row posts-md col-mb-30">
									<?php $__currentLoopData = $relatedblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="entry col-12 col-md-6">
										<div class="grid-inner row align-items-center gutter-20">
											<div class="col-4">
												<div class="entry-image">
													<a href="<?php echo e(URL::to('blog/'. $related->slug)); ?>"><img src="<?php echo e(asset('img/medium/'.$related->image)); ?>" alt="<?php echo e($related->title); ?>"></a>
												</div>
											</div>
											<div class="col-8">
												<div class="entry-title title-xs">
													<h3><a href="<?php echo e(URL::to('blog/'. $related->slug)); ?>"><?php echo e($related->title); ?></a></h3>
												</div>
												<div class="entry-meta">
													<ul>
														<li><i class="icon-calendar3"></i>  <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('M d, Y')); ?></li>
														<li><a href="#"><i class="icon-comments"></i> <?php echo e($related->comment_count); ?></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									

									

								</div>

								<!-- Comments
								============================================= -->
								<div id="comments" class="clearfix">

									<h3 id="comments-title"><span><?php echo e($blog->comment_count); ?></span> Comments</h3>

									<!-- Comments List
									============================================= -->
									<ol class="commentlist clearfix">
										<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="comment even thread-even depth-1" id="li-comment-1">
											<div id="comment-1" class="comment-wrap clearfix">
												<div class="comment-meta">
													<div class="comment-author vcard">
														<span class="comment-avatar clearfix">
														<img alt='Image' src='<?php echo e($comment->userinfo->avatar); ?>' class='avatar avatar-60 photo avatar-default' height='60' width='60' /></span>
													</div>
												</div>
												<div class="comment-content clearfix">
													<div class="comment-author"><?php echo e($comment->userinfo->name); ?><span><?php echo e(Carbon\Carbon::parse($comment->created_at)->format('M d, Y - h:i A')); ?></span></div>
													<p><?php echo strip_tags($comment->comment, '<b><i><strong><p>'); ?></p>
														<?php if(Auth::user()): ?>
															<a class='comment-reply-link' href='javascript:openmodal(<?php echo e($comment->id); ?>)'><i class="icon-reply"></i></a>
														<?php else: ?>
															<a class='comment-reply-link' href='<?php echo e(URL::to('login')); ?>'><i class="icon-reply"></i></a>
														<?php endif; ?>
												</div>
												<div class="clear"></div>
											</div>
											<?php if(count($comment->children)>0): ?>
											<ul class='children'>
												<?php $__currentLoopData = $comment->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li class="comment byuser comment-author-_smcl_admin odd alt depth-2" id="li-comment-3">
													<div id="comment-3" class="comment-wrap clearfix">
														<div class="comment-meta">
															<div class="comment-author vcard">
																<span class="comment-avatar clearfix">
																	<img alt='Image' src='<?php echo e($child->userinfo->avatar); ?>' class='avatar avatar-60 photo avatar-default' height='40' width='40' /></span>
																</div>
														</div>
														<div class="comment-content clearfix">
															<div class="comment-author"><?php echo e($child->userinfo->name); ?><span><?php echo e(Carbon\Carbon::parse($child->created_at)->format('M d, Y - h:i A')); ?></span></div>
															<p><?php echo strip_tags($child->comment, '<b><i><strong><p>'); ?></p>
														</div>
														<div class="clear"></div>
													</div>
												</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
											<?php endif; ?> 
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</ol><!-- .commentlist end -->
                    
                    <?php echo e($comments->withQueryString()->links()); ?>

									<div class="clear"></div>
									<?php if(Auth::user()): ?>
									<a href="javascript:openmodal()" 
										class="button button-3d m-0 float-right">Comment</a>
									<?php else: ?>
										<a href="<?php echo e(URL::to('login')); ?>"
											class="button button-3d m-0 float-right">Comment</a>
									<?php endif; ?>

									<!-- Modal Comments
                       ============================================= -->
					   <div class="modal fade" id="CommentFormModal" tabindex="-1" role="dialog"
					   aria-labelledby="CommentFormModalLabel" aria-hidden="true">
					   <div class="modal-dialog">
						   <div class="modal-content">
							   <div class="modal-header">
								   <h4 class="modal-title" id="CommentFormModalLabel">Submit a Comment</h4>
								   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							   </div>
							   <div class="modal-body">
								   <form class="row mb-0" id="Commentform" name="Commentform"
									   onsubmit="return save_comment();" method="post">										  
									   <div class="w-100"></div>
									   <div class="col-12 mb-3">
										   <label for="Commentform-Comment">Comment <small>*</small></label>
										   <textarea class="required form-control" id="Commentform-Comment" required
											   name="Commentform-Comment" rows="6" cols="30"></textarea>
											   <input type="hidden" id="Commentform-val" name="Commentform-val" value="">
									   <input type="hidden" id="Commentform-blogid" name="Commentform-blogid" value="<?php echo e($blog->id); ?>">
									   </div>
   
									   <div class="col-12">
										   <button class="button button-3d m-0" type="submit" id="Commentform-submit"
											   name="Commentform-submit" value="submit">Submit Comment</button>
									   </div>
   
								   </form>
							   </div>
							   <div class="modal-footer">
								   <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							   </div>
						   </div><!-- /.modal-content -->
					   </div><!-- /.modal-dialog -->
				   </div><!-- /.modal -->
				   <!-- Modal Comments End -->
									<!-- Comment Form
									============================================= -->
									
									<!-- #respond end -->

								</div><!-- #comments end -->

							</div>

						</div><!-- .postcontent end -->

						<!-- Sidebar
						============================================= -->
						<div class="sidebar col-lg-3">
							<div class="sidebar-widgets-wrap">

								<div class="widget clearfix no-padding">

									<div class="tabs mb-0 clearfix" id="sidebar-tabs">

										<ul class="tab-nav clearfix">
											<li><a href="#popular-tab">Popular</a></li>
											<li><a href="#recent-tab">Recent</a></li>
										</ul>

										<div class="tab-container">

											<div class="tab-content clearfix" id="popular-tab">
												<div class="posts-sm row col-mb-30" id="popular-post-list-sidebar">
													<?php $__currentLoopData = $popularblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="entry col-12">
														<div class="grid-inner row no-gutters">
															<div class="col-auto">
																<div class="entry-image">
																	<a href="<?php echo e($popular->slug); ?>"><img class="" src="<?php echo e(asset('img/small/'.$popular->image)); ?>" alt="<?php echo e($popular->title); ?>"></a>
																</div>
															</div>
															<div class="col pl-3">
																<div class="entry-title">
																	<h4><a href="<?php echo e($popular->slug); ?>"><?php echo e($popular->title); ?></a></h4>
																</div>
																<div class="entry-meta">
																	<ul>
																		<li><i class="icon-comments-alt"></i> <?php echo e($popular->comment_count); ?> Comments</li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
												</div>
											</div>
											<div class="tab-content clearfix" id="recent-tab">
												<div class="posts-sm row col-mb-30" id="recent-post-list-sidebar">
													<?php $__currentLoopData = $recentblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="entry col-12">
														<div class="grid-inner row no-gutters">
															<div class="col-auto">
																<div class="entry-image">
																	<a href="<?php echo e($recent->slug); ?>"><img class="" src="<?php echo e(asset('img/small/'.$recent->image)); ?>" alt="<?php echo e($recent->title); ?>"></a>
																</div>
															</div>
															<div class="col pl-3">
																<div class="entry-title">
																	<h4><a href="<?php echo e($recent->slug); ?>"><?php echo e($recent->title); ?></a></h4>
																</div>
																<div class="entry-meta">
																	<ul>
																		<li><i class="icon-comments-alt"></i> <?php echo e($recent->comment_count); ?> Comments</li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
											</div>

										</div>

									</div>

								</div>

								

							</div>
						</div><!-- .sidebar end -->
					</div>

				</div>
			</div>
		</section><!-- #content end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/readmore.min.js')); ?>"></script>
    <script>
		$( document ).ready(function() {

		$('#show-filter').click(function(){
			$('.sidebar').toggleClass('show-sidebar');
			$('.sidebar').toggle();
			$('.cat-filter').readmore({
  			speed: 75,
  			lessLink: '<a href="#">Read less</a>'
		});

		});
		});

		$('.cat-filter').readmore({
  			speed: 75,
  			lessLink: '<a href="#">Read less</a>'
		});
function openmodal(val){
	$('#Commentform-val').val(val);
	$("#CommentFormModal").modal()
}
	</script>

    <script type="text/javascript">
        $(function() {
            $('#Commentform').parsley();
        });

        function save_comment() {
			console.log('in form');
            if ($('#Commentform').parsley().validate()) {
                var comment = $("#Commentform-Comment").val();
                var parent_id = $('#Commentform-val').val();
                var blog_id = $('#Commentform-blogid').val();

                if (comment != "" ) {
					console.log('in comment');
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'post',
                        url: APP_URL + '/comment/submit',
                        data: {
                            comment: comment,
                            parent_id: parent_id,
							blog_id: blog_id
                        },
                        success: function(response) {
                            if (response.status) {
                                swal("Thankyou!",
                                    "Comment Submitted Successfully!",
                                    "success");
									$('#CommentFormModal').modal('hide');
                            } else {
                                swal("Oops!", "Something went wrong, Please try again", "warning");
                            }
                        }
                    });
                    swal("Thankyou!", "Comment Submitted Successfully!",
                        "success");
						$('#CommentFormModal').modal('hide');

                }
            }

            return false;
        }
		$(function() {
			$( "i.like-icon" ).click(function() {
			$( "i.like-icon,span.like-txt" ).toggleClass( "press", 1000 );
			});
		});


		// Like Button

		$('.likebtn').click(function() {
            $blogid = $(this).data('blogid');
            $btnLike = $(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'post',
                url: APP_URL + '/blog/like',
                data: {
                    blogid: $blogid
                },
                success: function(response) {
                    if (response.status) {
                        $btnLike.removeClass("btn-outline-dark").addClass("btn-primary");
                    } else {
                        $btnLike.addClass("btn-outline-dark").removeClass("btn-primary");
                    }
                    $('#like-' + $blogid).html(response.likecpy);
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/blog/inner.blade.php ENDPATH**/ ?>