

<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="search-title">
        <div class="container clearfix">
            <div class="col-md-8 offset-md-2">
                <div class="shadow">

                    <div class="input-group input-group-lg mt-1 home-searchbar">

                        <input class="form-control rounded border-0 main-search" type="search"
                            placeholder="Search ends here.." aria-label="Search">
                        <div class="form-group mb-0">
                            <select id="single" class="form-control select2-single">
                                <option value="mu">Mumbai</option>
                                <option value="dh">Delhi</option>
                                <option value="pn">Pune</option>
                                <option value="ke">Kerala</option>
                            </select>
                        </div>
                        <div class="input-group-append search-btn">
                            <button class="btn" type="submit"><i class="icon-line-search font-weight-bold"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- #page-title end -->
    <!-- Content
      ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">


                    <!-- Post Content
          ============================================= -->
                    <div class="postcontent col-lg-8">

                        <h3 class="main-que shadow-sm border"><span class="que-sign">Q.</span> <?php echo e($question->title); ?></h3>
                        <div class="badge badge-pill badge-secondary font-weight-bold"><?php echo e(count($question->answers)); ?> answers</div>
                        <hr class="py-2">
                        <div id="reviews" class="clearfix mt-2">
                            
                            <ol class="commentlist clearfix border-0">
                                <?php if(count($question->answers) <= 0): ?>
                                <li class="comment even thread-even depth-1 border-bottom" id="li-comment-1">
                                    <div id="comment-1" class="comment-wrap clearfix">

                                        <div class="comment-meta">
                                            <div class="comment-author vcard">

                                            </div>
                                        </div>

                                        <div class="comment-content clearfix">
                                            <div class="comment-author"></span>
                                            </div>
                                            <p>&nbsp;</p>
                                            This Question is not answered yet
                                        </div>
                                    </div>
                                </li>
                            <?php else: ?>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="comment even thread-even depth-1 border-bottom" id="li-comment-1">
                                    <div id="comment-1" class="comment-wrap clearfix">

                                        <div class="comment-meta">
                                            <div class="comment-author vcard">
                                                <span class="comment-avatar clearfix">
                                                    <img alt="Image"
                                                        src="<?php echo e($answer->user->avatar); ?>"
                                                        height="40" width="40"></span>
                                            </div>
                                        </div>

                                        <div class="comment-content clearfix">
                                                        <div class="comment-author"><?php echo e($answer->user->name); ?>,
                                                            <?php echo e($answer->user->qualification); ?> <span><a href="#"
                                                                    title="Permalink to this comment"><?php echo e(Carbon\Carbon::parse($answer->created_at)->format('M d, Y - h:i A')); ?></a></span>
                                                        </div>
                                                        <p>&nbsp;</p>
                                                        <?php echo $answer->answer; ?>

                                        </div>

                                        <div class="btns d-flex">
                                        <?php if(Auth::user()): ?>
                                            <?php if(Auth::user()->hasLiked($answer)): ?>
                                            <!-- Like btn -->
                                            <a class="btn btn-lg btn-shared btn-like liked" data-ansid="<?php echo e($answer->id); ?>"><span
                                                class="icon-like pull-left"></span><span
                                                class="like-text" id="like-<?php echo e($answer->id); ?>" style="display: none">Like</span><span class="unlike-text" id="unlike-<?php echo e($answer->id); ?>" style="display: inline">Unlike</span></a>
                                            <!-- / -->
                                                
                                                
                                            <?php else: ?>
                                            <a class="btn btn-lg btn-shared btn-like unliked" data-ansid="<?php echo e($answer->id); ?>"><span
                                                class="icon-like pull-left"></span><span
                                                class="like-text" id="like-<?php echo e($answer->id); ?>" style="display: inline">Like</span><span class="unlike-text" id="unlike-<?php echo e($answer->id); ?>" style="display: none">Unlike</span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span id="like-<?php echo e($answer->id); ?>"><?php echo e($answer->likers()->count()); ?>

                                                <i class="icon-thumbs-up"></i></span>
                                            <a type="button" class="btn btn-sm btn-outline-dark"
                                                href="<?php echo e(URL::to('login')); ?>"><i class="icon-thumbs-up"></i>
                                                Like</a>
                                        <?php endif; ?>
                                            

                                            <!-- share btn -->
                                            <div class="share">
                                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(Request::url()); ?>">
                                                    <div class="icon first"><i class="icon-facebook"></i></div>
                                                </a>
                                                <a href="https://twitter.com/intent/tweet?text=<?php echo e($question->title); ?>&amp;url=<?php echo e(Request::url()); ?>">
                                                    <div class="icon"><i class="icon-twitter"></i></div>
                                                </a>
                                                <a href="https://wa.me/?text=<?php echo e(Request::url()); ?>">
                                                    <div class="icon"><i class="icon-whatsapp"></i></div>
                                                </a>
                                                <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(Request::url()); ?>&amp;title=<?php echo e($question->title); ?>">
                                                    <div class="icon last"><i class="icon-linkedin"></i></div>
                                                </a>
                                                <div class="label">Share</div>
                                            </div>
                                            <!-- / -->
                                        </div>  
                                        <div class="clear"></div>

                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ol>
                        </div>



                    </div><!-- .postcontent end -->

                    <!-- Sidebar
          ============================================= -->
                    <div class="sidebar col-lg-4 d-block ">
                        <div class="sidebar-widgets-wrap related-que shadow-sm">

                            <div class="widget widget_links text-left qwidget">

                                <h4>Related Questions</h4>
                                <?php $__currentLoopData = $relatedQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><a
                                            href="<?php echo e(URL::to('question/' . $relatedQuestion->slug)); ?>"><?php echo e($relatedQuestion->title); ?></a>
                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>


                        </div>
                    </div><!-- .sidebar end -->


                </div>

            </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <script type="text/javascript">
        $(function() {
            //$('#contactform').parsley();
        });

        $('.btn-like').click(function() {
            $answerid = $(this).data('ansid');
            $btnLike = $(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'post',
                url: APP_URL + '/answer/like',
                data: {
                    answerid: $answerid
                },
                success: function(response) {
                    if (response.status) {
                        $btnLike.addClass("liked");
                        $('#unlike-' + $answerid).show();
                        $('#like-' + $answerid).hide();
                    } else {
                        $btnLike.removeClass("liked");
                        $('#unlike-' + $answerid).hide();
                        $('#like-' + $answerid).show();
                    }
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/qa/question.blade.php ENDPATH**/ ?>