<?php $__env->startSection('content'); ?>
<section id="content" class="loginpage">
    <div class="content-wrap">
        <div class="container-fluid" style="max-width: 850px;">

            <div class="row">

                <div class="col-lg-5 login-right card">
                    <img src="images/login2.svg" alt="Login">
                <h3>Welcome to Finest 50</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit ipsum dolor sit amet.</p>

                </div>

                <div class="col-12 col-lg-7 mb-0 login-left">
                    <div class="card mb-0">
                        <div class="card-body" style="padding: 40px;">
                            <h3><?php echo e(__('Register')); ?></h3>

                            <form id="register-form" name="register-form" class="row mb-0" method="POST"
                            onsubmit="return registerpage();">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 form-group">
                                    <label for="name"
                                        class=""><?php echo e(__('Name')); ?></label>
                                    <input id="name" type="text"
                                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                        value="<?php echo e(old('name')); ?>" required autocomplete="name"
                                        autofocus>
                                        <span id="name_error"></span>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 form-group">
                                    <label for="email"
                                        class=""><?php echo e(__('E-Mail Address')); ?></label>

                                    <input id="email" type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                        value="<?php echo e(old('email')); ?>" autocomplete="email" data-parsley-type="email" data-parsley-trigger="change">
                                        <span id="email_error"></span> 
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 form-group">
                                    <label for="mobile"
                                        class="">Mobile </label>

                                    <input id="phone" type="tel"
                                        class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile"
                                        value="<?php echo e(old('mobile')); ?>" autocomplete="phone" data-parsley-pattern="^[6-9]\d{9}$">
                                        <span id="mobile_error"></span>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 form-group">
                                    <button class="button button-3d button-primary m-0" id="register-form-submit"
                                        name="register-form-submit" value="register" type="submit">Register</button>
                                </div>

                                <div class="divider my-3"></div>

                                <div class="col-12 form-group">

                                    Already have an account? <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </div>

                            </form>

                            
                            <form id="otp-form" name="otp-form" class="row mb-0" method="POST"
                            onsubmit="return verifyotp();" style="display:none">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 form-group">
                                    <label for="otp"
                                        class="">OTP</label>
                                    <input id="otp" type="text"
                                        class="form-control <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otp"
                                        value="<?php echo e(old('otp')); ?>" required
                                        autofocus>
                                    <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 form-group">

                                    Resend OTP <a href="#">Resend</a>
                                </div>

                                <div class="col-12 form-group">
                                    <button class="button button-3d button-primary m-0" id="otp-form-submit"
                                        name="otp-form-submit" value="otp" type="submit">Verify</button>
                                </div>

                                <div class="divider my-3"></div>

                                <div class="col-12 form-group">

                                    Already have an account? <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </div>

                            </form>
                            

                        </div>
                    </div>


                </div>

            </div>
            <!-- row end -->

        </div>
    </div>
</section><!-- #content end -->
<!-- Ends -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    var uid=0;
    var redirectto = "<?php echo e(url()->previous()); ?>";
    $(function() {
        $('#register-form').parsley();
    });

    function registerpage() {
        if ($('#register-form').parsley().validate()) {
            var name = $("#name").val();
            var mobile = $("#phone").val();
            var email = $("#email").val();

            if (name != "" && ( email != "" || mobile != "")) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'post',
                    url: 'optregister',
                    data: {
                        name: name,
                        email: email,
                        mobile: mobile
                    },
                    success: function(response) {
                        if (response.status) {
                            $('#otp-form').show();
                            $('#register-form').hide();
                            swal("Thankyou!",
                                "We have recieved your request, someone from our team will contact you shortly!",
                                "success");
                            uid=response.id;
                            console.log("uid - "+ uid);
                        } else {
                            
                            swal("Oops!", "Something went wrong, Please try again", "warning");
                        }
                    },
                    error: function (reject) {
                        // if( reject.status === 401 ) {
                            var errors = $.parseJSON(reject.responseText);
                            console.log(errors);
                            $.each(errors.error, function (key, val) {
                                console.log("errors  - ");
                                console.log(key + " - - " + val[0] );

                                $("#" + key + "_error").text(val[0]);
                            });
                        // }
                    }
                });
            }
            else{
            swal("Oops!", "Enter Mobile or Email",
                    "warning");
                }
        }

        /* else
       {
        swal("Please Fill All The Details");
       }*/

        return false;
    }
    function verifyotp() {
        if ($('#otp-form').parsley().validate()) {
            var otp = $("#otp").val();
            console.log(otp + " - " + uid);
            if (otp != "" && uid != "" ) {
                console.log(uid);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'post',
                    url: 'verifyotp',
                    data: {
                        uid: uid,
                        otp: otp,
                        
                    },
                    success: function(response) {
                        console.log(response); 
                        if (response.status) {
                            // window.history.back();
                            window.location.replace(redirectto);
                        } else {
                            swal("Oops!", "Wrong OTP, Please try again", "warning");
                        }
                    }
                });
            }
            else{
            swal("Oops!", "Something is not right",
                    "warning");
                }
        }

        /* else
       {
        swal("Please Fill All The Details");
       }*/

        return false;
    }
</script>
<?php $__env->stopSection(); ?> 
<!-- register  -->



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/auth/register-otp.blade.php ENDPATH**/ ?>