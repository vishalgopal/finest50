

<?php $__env->startSection('title'); ?>
    Search - <?php echo e($query); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title
          ============================================= -->
    
    <!-- #page-title end -->

    <!-- Content ============================================= -->
    <section id="content">
        <div class="content-wrap">

            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">

                    <!-- Post Content   ============================================= -->
                    <div class="postcontent col-12">

								<?php if(count($questions)>0): ?>
                                <div class="page-title">
                                    <h2>Popular Q&A</h2>
                                </div>
								
								
                                <div class="posts-sm row col-mb-30" id="popular-post-list-sidebar">
									<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
									<div class="entry col-12">
                                        <div class="grid-inner row no-gutters">
                                            <div class="col-auto">
                                                <div class="entry-image">
                                                </div>
                                            </div>
                                            <div class="col pl-3">
                                                <div class="entry-title">
                                                    <h4><a href="<?php echo e(URL::to('question/' . $question->slug)); ?>"><?php echo e($question->title); ?></a></h4>
                                                </div>
                                                <div class="entry-meta">
                                                    <ul>
                                                        <li><i class="icon-comments-alt"></i> <?php echo e($question->answers_count); ?> Answers</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- q and a end -->
                            </div>
                            <div class="divider"><i class="icon-circle"></i></div>
                            <?php else: ?>
                                No Resuts Found!!
							<?php endif; ?>
                        </div>
                        <?php echo e($questions->withQueryString()->links()); ?>



                    </div><!-- #search end -->


                </div><!-- .postcontent end -->


            </div>

        </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="js/jquery.matchHeight-min.js"></script>
    <script>
        $(function() {
            $('.feature-box').matchHeight();
            $('.search-all-members .fbox-content h3').matchHeight();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/search/questions.blade.php ENDPATH**/ ?>