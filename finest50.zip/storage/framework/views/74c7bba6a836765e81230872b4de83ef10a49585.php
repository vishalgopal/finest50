

<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('meta'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title
      ============================================= -->
    <section class="search-title">
        <div class="container clearfix">
            <div class="col-md-8 offset-md-2">
                <div class="shadow">

                    <div class="input-group input-group-lg mt-1 home-searchbar">

                        <input class="form-control rounded border-0 main-search" type="search"
                            placeholder="Search ends here.." aria-label="Search">
                        <div class="form-group mb-0">
                            <select id="single" class="form-control select2-single">
                                <option value="mu">Mumbai</option>
                                <option value="dh">Delhi</option>
                                <option value="pn">Pune</option>
                                <option value="ke">Kerala</option>
                            </select>
                        </div>
                        <div class="input-group-append search-btn">
                            <button class="btn" type="submit"><i class="icon-line-search font-weight-bold"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- #page-title end -->

    <!-- Content
      ============================================= -->
    <section id="content">
        <div class="content-wrap">

            <div class="container clearfix">

                <div class="row gutter-40 col-mb-80">

                    <!-- Post Content
          ============================================= -->
                    <div class="postcontent col-12">

                        <!-- Filter Begin -->
                        <div class="search-filter">

                            <a href="Javascript:void(0);" class="badge badge-pill badge-light" id="btn-apply-filter"
                                onclick="$('.all-filters').toggle()">Narrow your search, Apply Filters <i
                                    class="icon-angle-down1"></i></a>

                            <ul class="all-filters" style="display: none;">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="custom-control custom-checkbox">
                                        <input type="checkbox" name="categories" value="<?php echo e($category->slug); ?>" class="custom-control-input categories" <?php if(in_array($category->slug,$selectedCategories)): ?> checked <?php endif; ?> id="category<?php echo e($category->id); ?>">
                                        <label class="custom-control-label" for="category<?php echo e($category->id); ?>"><?php echo e($category->title); ?></label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="btn btn-follow float-right filter">Apply</div>
                            </ul>
                            
                        </div>
                        <!-- Filter End -->

                        <div class="page-title">
                            <h2>Members</h2>
                            <div class="from-group">
                                <button class="btn btn-sm btn-outline-dark dropdown-toggle"
                                    type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <i class="icon-share"></i> Sort By <?php if(Request::has('sortby')): ?><?php echo e("- " . ucwords(Request::get('sortby'))); ?> <?php endif; ?> </button>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="<?php echo e(Request::url()); ?>">None</a>
                                    <a class="dropdown-item" href="<?php echo e(Request::url().'?sortby=rating'); ?>">Highest Rated</a>
                                    <a class="dropdown-item" href="<?php echo e(Request::url().'?sortby=reviews'); ?>">Most Reviewed</a>
                                    <a class="dropdown-item" href="<?php echo e(Request::url().'?sortby=follower'); ?>">Followers</a>
                                    <a class="dropdown-item" href="<?php echo e(Request::url().'?sortby=stories'); ?>">Stories</a>
                                    <a class="dropdown-item" href="<?php echo e(Request::url().'?sortby=answers'); ?>">Answers</a>
                                </div>

                            </div>
                        </div>
                        
                        <!-- Shop
           ============================================= -->
                        <div id="shop" class="shop row" data-layout="fitRows">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product">
                                    <div class="grid-inner row ">
                                        <div class="product-image col-3 col-lg-3 col-xl-2">
                                            <a href="<?php echo e(URL::to('member/' . $user->slug)); ?>"><img src="<?php echo e($user->avatar); ?>"
                                                    alt="<?php echo e($user->name); ?>"></a>
                                            <!-- <div class="sale-flash badge badge-secondary p-2">Out of Stock</div> -->
                                        </div>
                                        <div class="product-desc col-9 col-lg-8 col-xl-9 px-lg-5 pt-lg-0">
                                            <div class="product-title">
                                                <h3><a href="<?php echo e(URL::to('member/' . $user->slug)); ?>"><?php echo e($user->name); ?></a>
                                                </h3>
                                            </div>
                                            <div class="product-price"><?php echo e($user->qualification); ?></div>
                                            <div class="product-rating">
                                                <?php echo $user->rating; ?>

                                            </div>

                                            <p class="mt-2 mb-2 d-none d-lg-block"><?php echo e($user->short_description); ?></p>
                                            <div class="number-section">
                                                <div>
                                                    <div class="d-flex mb-2">
                                                    <p class="text-dark my-0" id="followers-<?php echo e($user->id); ?>"><strong><?php echo e($user->follower); ?></strong>
                                                            Followers</p>
                                                        <p class="mx-3 mb-0">|</p>
                                                        <p class="text-dark my-0">
                                                            <a href="<?php echo e(URL::to('member/' . $user->slug . '/blogs')); ?>"><strong><?php echo e($user->stories); ?></strong>
                                                            Stories</a></p>
                                                        <p class="mx-3 mb-0">|</p>
                                                        <p class="text-dark my-0"><strong><?php echo e($user->answers); ?></strong>
                                                            Answers</p>
                                                    </div>
                                                </div>
                                                <div>
                                                    <?php if(Auth::user()): ?>
                                                    <a class="follow-btn" data-uid="<?php echo e($user->id); ?>">
                                                    <?php if(Auth::user()->isFollowing($user)): ?>
                                                        <div class="btn btn-follow mt-0 btn-outline-dark">Unfollow</div>
                                                    <?php else: ?> 
                                                        <div class="btn btn-follow mt-0 btn-outline-dark">Follow</div>
                                                    <?php endif; ?>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(URL::to('/login')); ?>"><div class="btn btn-follow ">Follow</div></a>   
                                                <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php echo e($users->withQueryString()->links()); ?>

                        </div><!-- #shop end -->


                    </div><!-- .postcontent end -->


                </div>

            </div>
        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/readmore.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {

            $('#show-filter').click(function() {
                // $('.sidebar').toggleClass('show-sidebar');
                $('.sidebar').toggle();
                $('.cat-filter').readmore({
                    speed: 75,
                    lessLink: '<a href="#">Read less</a>'
                });

            });
        });

        $('.cat-filter').readmore({
            speed: 75,
            lessLink: '<a href="#">Read less</a>'
        });

        $('#btn-apply-filter').click(function() {
            $('#btn-apply-filter i').toggleClass('icon-angle-up1');
            // $('i').addClass('icon-angle-up1');
        })
        $('.filter').click(function(){
            var categories = [];
                $.each($("input[name='categories']:checked"), function(){
                    categories.push($(this).val());
            });
            var url = new URL(document.location);
            var params = url.searchParams;
            var sortby = params.get("sortby");
            if(sortby)
            {
               document.location = APP_URL + '/search/member/<?php echo e($query); ?>?categories=' + categories.join(",") + "&sortby=" + sortby ;
            }
            else
            {
               document.location = APP_URL + '/search/member/<?php echo e($query); ?>?categories=' + categories.join(",");
            }
        })
    </script>
    <script type="text/javascript">
        $(function() {
            $('#contactform').parsley();
        });

        function save_contact() {
            if ($('#contactform').parsley().validate()) {
                var firstname = $("#contactform-firstname").val();
                var lastname = $("#contactform-lastname").val();
                var email = $("#contactform-email").val();
                var phone = $("#contactform-phone").val();
                var category_id = $("#contactform-category_id").val();
                var subject = $("#contactform-subject").val();
                var message = $("#contactform-message").val();
                var phone_code = $("#contactform-phone_code").val();

                if (firstname != "" && email != "") {
                    $(".form-process").css({
                        "display": "block"
                    });
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'post',
                        url: 'contact/submit',
                        data: {
                            firstname: firstname,
                            lastname: lastname,
                            email: email,
                            phone: phone,
                            category_id: category_id,
                            subject: subject,
                            message: message,
                            phone_code: phone_code,
                        },
                        success: function(response) {
                            if (response.status) {
                                swal("Thankyou!",
                                    "We have recieved your request, someone from our team will contact you shortly!",
                                    "success");
                                $(".form-process").css({
                                    "display": "none"
                                });
                            } else {
                                swal("Oops!", "Something went wrong, Please try again", "warning");
                            }
                        }
                    });
                    swal("Thankyou!", "We have recieved your request, someone from our team will contact you shortly!",
                        "success");
                    $(".form-process").css({
                        "display": "none"
                    });
                }
            }

            /* else
           {
            swal("Please Fill All The Details");
           }*/

            return false;
        }
        $('.follow-btn').click(function () {
        $member_id = $(this).data('uid');
        currentbtn = $(this);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'post',
            url: APP_URL + '/member/follow',
            data: {
                member_id: $member_id
            },
            success: function (response) {
                if (response.status) {
                    $(currentbtn).html('<div class="btn btn-follow ">Unfollow</div>');
                } else {
                    $(currentbtn).html('<div class="btn btn-follow ">Follow</div>');
                }
                $('#followers-'+$member_id).html('<strong>' + response.count + '</strong> Follower(s) ')
                // $('#like-' + $answerid).html(response.likecpy);
            }
        });
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishal\finest50\resources\views/search/members.blade.php ENDPATH**/ ?>